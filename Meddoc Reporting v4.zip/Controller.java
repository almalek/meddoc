package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import java.io.File;

public class Controller {

    public ObservableList<File> childList = FXCollections.observableArrayList();

    private int imgCount, docCount, otherCount;

    public void selPress(){
        imgCount = 0;
        docCount = 0;
        otherCount = 0;
        DirectoryChooser chooser = new DirectoryChooser();
        chooser.setTitle("Select Directory.");
        chooser.setInitialDirectory(new File(System.getProperty("user.home")));
        try {
            final File selected = chooser.showDialog(new Stage());
            getFiles(selected);
            dispFiles();
        }catch(NullPointerException ignored){ }
    }

    private void dispFiles(){
        DisplayFiles Displayer = new DisplayFiles(childList, imgCount, docCount, otherCount, this);
        Displayer.disp();
    }

    private void getFiles(File selected) {
        File[] children = selected.listFiles();
        if(children != null){
            for(File child : children){
                sortFile(child);
                childList.add(child);
            }
        }
    }

    private void sortFile(File child) {
        String fileName = child.toString();
        String extension = "";
        int ext = fileName.lastIndexOf(".");
        if(ext > 0){
            extension = fileName.substring(ext + 1);
        }
        switch(extension){
            case "png":
            case "jpg":
            case "gif":
            case "bmp": {
                imgCount++;
                break;
            }
            case "docx":
            case "doc":
            case "txt":
            case "pdf":
            case "java":
            {
                docCount++;
                break;
            }
            default:
            {
                otherCount++;
                break;
            }
        }
    }
}
