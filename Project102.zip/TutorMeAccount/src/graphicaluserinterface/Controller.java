package graphicaluserinterface;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import production.User;


public class Controller {

    @FXML
    private Label display;

    @FXML
    private TextField firstName;

    @FXML
    private TextField lastName;
    @FXML
    private TextField emailAddress;
    @FXML
    private TextField userName;
    @FXML
    private PasswordField password;
    @FXML
    private PasswordField reenterPassword;

    @FXML
    private void makeUserAccount(ActionEvent actionEvent){
        boolean formTrue =true;
        String s="Passwords do not match  " ;
        if(firstName.getText().equals("")){
            s+= "firstName";
            formTrue =false;
        }if(lastName.getText().equals("")){
            s+= ",lastName";
            formTrue =false;
        }if(emailAddress.getText().equals("")){
            s+= ",Email";
            formTrue =false;
        }if(userName.getText().equals("")){
            s+= ",userName";
            formTrue =false;
        }
        if(password.getText().equals("")){
            s+= ",password";
            formTrue =false;
        }
        if(reenterPassword.getText().equals("")){
            s+= ",Re-Enter Password";
            formTrue =false;
        }
        if(formTrue && password.getText().equals(reenterPassword.getText())){
            User user = new User(firstName.getText(),lastName.getText(),emailAddress.getText(),password.getText(),userName.getText());
            System.out.println(user);

           {
                display.setText("Congratulations!");
            }
        }else{
            if(!password.getText().equals(reenterPassword.getText())){
                display.setText("Passwords do not Match");
                System.out.println("Passwords do not Match");
            }
            System.out.println(s);
            display.setText(s);
        }


    }


}
