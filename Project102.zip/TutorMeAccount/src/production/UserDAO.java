package production;

import java.sql.Connection;

public class UserDAO {

    private Connection connection;

    private Connection createConnection(){

        return connection;
    }



    public boolean insert(User user){
        //insertion into the DB happens here.
        return true;
    }

    public boolean checkEmailDuplicate(String email){
        //check if the email exists already
        return false;
    }

    public boolean delete(User user){
        //delete the user
        return false;
    }


}
