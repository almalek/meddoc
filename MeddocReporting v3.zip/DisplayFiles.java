package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.awt.*;
import java.io.File;
import java.io.IOException;

public class DisplayFiles{

    private final ObservableList<File> childList;

    private int OpenList;

    private int imgCount;

    private int docCount;

    private int otherCount;

    private Stage primaryStage = new Stage();

    private Scene scene;

    private Button btnOpen, btnCancel2;

    private Label lblImFound, lblDocFound, lblOtherFound, lblLabel1, lblLabel2, lblLabel3;

    private Controller c;

    ListView<String> tblResults = new ListView<>();

    private boolean flag = false;

    public void cancelPress(){
        primaryStage.close();
        this.imgCount = 0;
        this.docCount = 0;
        this.otherCount = 0;
        childDelete();
    }

    public void openPress(){
        OpenList = tblResults.getSelectionModel().getSelectedIndex();
            try {
                Desktop.getDesktop().open(childList.get(OpenList));
            }catch(IOException e){}
    }

    public DisplayFiles(ObservableList<File> childList, int imgCount, int docCount, int otherCount, Controller c) {
        this.childList = childList;
        this.imgCount = imgCount;
        this.docCount = docCount;
        this.otherCount = otherCount;
        this.c = c;
        fillTable();
    }

    private void childDelete() {
        for(int i = 0; i <= c.childList.size() + 1; i++) {
            c.childList.remove(0);
        }
    }

    private void fillTable() {
        ObservableList<String> StringList = FileTOString();
        tblResults.setItems(StringList);
        tblResults.editableProperty().setValue(false);
        tblResults.setPrefWidth(500.0);
        tblResults.setOnMouseClicked(e -> handle(e));
    }

    private ObservableList<String> FileTOString() {
        ObservableList<String> StringList = FXCollections.observableArrayList();
        String temp;
        for(File i: childList){
            temp = i.toString();
            temp = temp.substring(temp.lastIndexOf("\\") + 1);
            StringList.add(temp);
        }
        return StringList;
    }

    public void handle(MouseEvent click) {
        if (click.getClickCount() == 2) {
            openPress();
        }
    }

    public void disp() {
        if(this.childList.size() < 1){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("No Files Found");
            alert.setHeaderText("File Not Found.");
            alert.setContentText("No Files Were Found In Specified Directory.");
            alert.showAndWait();
            flag = true;
        }
        if(!flag) {
            primaryStage.setTitle("Files In Database");
            scene = buildScene();
            primaryStage.setScene(scene);
            primaryStage.show();
        }
    }

    private Scene buildScene() {
        setValues();
        AnchorPane pane = new AnchorPane();
        HBox hbox = new HBox();
        hbox.setAlignment(Pos.CENTER);
        hbox.setSpacing(30);
        VBox box = new VBox();
        VBox box2 = new VBox();
        box2.setSpacing(20);
        box2.getChildren().addAll(btnOpen, btnCancel2);
        box2.setAlignment(Pos.CENTER);
        Pane pan = new Pane();
        pan.setPrefHeight(40);
        box.getChildren().addAll(lblLabel1, lblImFound, lblLabel2, lblDocFound, lblLabel3, lblOtherFound, pan, box2);
        box.setAlignment(Pos.CENTER);
        hbox.getChildren().addAll(tblResults, box);
        pane.getChildren().add(hbox);
        Scene scene = new Scene(pane, 800, 400);
        return scene;
    }

    private void setValues() {
        lblLabel1 = new Label();
        lblLabel1.setText("Number of Images Found:");

        if(Integer.toString(imgCount) != null){
            lblImFound = new Label();
            lblImFound.setText(Integer.toString(imgCount));
        }

        lblLabel2 = new Label();
        lblLabel2.setText("Number of Documents Found:");

        if(Integer.toString(docCount) != null){
            lblDocFound = new Label();
            lblDocFound.setText(Integer.toString(docCount));
        }

        lblLabel3 = new Label();
        lblLabel3.setText("Number of other files in directory:");

        if(Integer.toString(otherCount) != null){
            lblOtherFound = new Label();
            lblOtherFound.setText(Integer.toString(otherCount));
        }

        btnOpen = new Button();
        btnOpen.setText("Open Selected File");
        btnOpen.setOnAction(e -> openPress());

        btnCancel2 = new Button();
        btnCancel2.setText("Cancel");
        btnCancel2.setOnAction(e -> cancelPress());
    }
}